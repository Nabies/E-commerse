public class productDetail
{
    private String id;
    private String name;
    private String price;
    private String color;
    private String model;

    public String getID()
    {
        return id;
    }
    protected void setID(String id)
    {
        this.id = id;
    }
    public String getName()
    {
        return name;
    }
    protected void setName(String name)
    {
        this.name = name;
    }
    public String getPrice()
    {
        return price;
    }
    protected void setPrice(String price)
    {
        this.price = price;
    }
    public String getColor()
    {
        return color;
    }
    protected void setColor(String color)
    {
        this.color = color;
    }
    public String getModel()
    {
        return model;
    }
    protected void setModel(String model)
    {
        this.model=model;
    }
}

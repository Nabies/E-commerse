public class PaymentStrategy
{
    public int pay;

    public void getPay()
    {
        System.out.println(pay+" paid with credit/debit card");
    }
    public void setPay(int pay)
    {
        this.pay = pay;
    }
}